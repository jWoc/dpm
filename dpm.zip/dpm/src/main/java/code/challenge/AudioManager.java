package code.challenge;

// class for operations on audio files
// function correct audio files
// input: audio file, output: audio file with corrected grammar
public class AudioManager {
    public AudioManager(byte [] data, String filename ) {

    }

    public void grammarCorrectionAudio() {
    }

    private void audioToText() {
    }

    private void textToAudio() {
    }

    private void grammarCorrectionText() {
    }
}
